$(document).ready(function(){
/*
*animation library
 */
  new WOW().init();
/*
*smooth scroll
 */
function startFunction() {
 var headerHeight1
 if ($('body').width() >= 1125){
   headerHeight1=64
 }else{
   headerHeight1=48
 }
 $("a[href*=#]").on("click", function (e) {
    var anchor = $(this);
    $('html, body').stop().animate({
      scrollTop: $(anchor.attr('href')).offset().top-headerHeight1
    }, 777);
    e.preventDefault();
    return false;
  });
}
startFunction()
/*
*HEADER add class active
*/
$(window).scroll(function(){
  $(".header a[href*=#]").each(function () {
    var window_top = $(window).scrollTop();
    var div_1 = $(this).attr('href');
    var div_top = $(div_1).offset().top;

    if (window_top > div_top - 100){
      $('.header').find('a').removeClass('active');
      $('.header').find('a[href="'+div_1+'"]').addClass('active');
    }
    else{
      $('.header').find('a[href="'+div_1+'"]').removeClass('active');
    };
  });
});
/*hamburger*/
$("a.nav-link").click(function() {
   $("#trigger").dropdown("toggle");
   hamburger.classList.toggle("is-active");
});
/*hamburger*/
var hamburger = document.querySelector(".hamburger");
hamburger.addEventListener("click", function() {
  hamburger.classList.toggle("is-active");
});
})//END $(document).ready
/*
*HEADER change height
*/
document.onscroll = function() {
  if (window.scrollY >5&&$('body').width() >= 997 ) {
    $('.navbar').addClass('navbar-small');
  }

  if (window.scrollY <= 0&&$('body').width() >= 997 ) {
      $('.navbar').removeClass('navbar-small');
  }
};
